## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(HW1Mantautas)

## ---- eval=FALSE--------------------------------------------------------------
#  predictor=rnorm(100)
#  response=rnorm(100)
#  simp_lin_R(y=response, x=predictor)

## ---- eval=FALSE--------------------------------------------------------------
#  variable1=seq(0,100,length=50)
#  variable2=seq(100,60, length=50)
#  simp_lin_R(variable1, variable2)

## -----------------------------------------------------------------------------
predictor=rnorm(20)
response=rnorm(20)
linear_reg <- simp_lin_R(y=response, x=predictor)
linear_reg$Coefficients
linear_reg$Fitted
linear_reg$MSE
linear_reg$Standard_Error
linear_reg$Residuals
linear_reg$`95pct_conf`

## -----------------------------------------------------------------------------
plot(x=predictor, y=response)
lines(x=predictor, y=linear_reg$Fitted, col="red")

